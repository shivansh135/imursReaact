import React from 'react'

export default function Price() {
  return (
    <div>pricP</div>
  )
}
