import React from "react";
import "./product-title.css";

export const ProducTitle = () => {
    return (
        <div className="product-frame">
            <div className="product-text-wrapper">Wedding Souvenir</div>
            <div className="payal-dharmesh">Payal &amp; Dharmesh</div>
        </div>
    );
};
